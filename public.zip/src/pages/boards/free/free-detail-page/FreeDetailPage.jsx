import { useNavigate, useParams } from "react-router-dom";
import { CommunityDetail } from "../../../../components/CommunityDetail";

export default function FreeDetailPage() {
    const { boardId, freeId } = useParams();
    const navigate = useNavigate();

    const onNavigate = (key) => {
        if (key === "community") navigate(`/boards/${boardId}/free`);
    };

    return (
        <>
            <CommunityDetail postId={freeId} onNavigate={onNavigate} />
        </>
    );
}
