import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserProfile } from '../../../components/user-profile/UserProfile';

const RECIPE_BOARD_ID = 1;

export default function MyProfilePage() {
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem('AccessToken');
        if (!token) navigate('/');
    }, [navigate]);

    const onNavigate = (key) => {
        if (key === 'home') navigate('/');
        if (key === 'profile') navigate('/me');
    };

    const onFollowersClick = () => navigate('/me/followers');
    const onFollowingClick = () => navigate('/me/following');

    const handleRecipeClick = (recipeId, e) => {
        // e.stopPropagation() etc if needed
        navigate(`/board/${RECIPE_BOARD_ID}/recipe/${recipeId}`);
    };

    const handleEditClick = (recipeId) => {
        navigate(`/board/${RECIPE_BOARD_ID}/recipe/${recipeId}/edit`);
    };

    const onLogout = () => {
        localStorage.removeItem('AccessToken');
        navigate('/');
    };

    const handleCommunityPostClick = (postId) => {
        // Community is board 2
        navigate(`/board/2/free/${postId}`);
    };

    return (
        <UserProfile
            onNavigate={onNavigate}
            onFollowersClick={onFollowersClick}
            onFollowingClick={onFollowingClick}
            onRecipeClick={handleRecipeClick}
            onCommunityPostClick={handleCommunityPostClick}
            onLogout={onLogout}
        />
    );
}
