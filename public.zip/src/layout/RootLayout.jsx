// src/layout/RootLayout.jsx
import { Outlet, useNavigate } from "react-router-dom";
import { useEffect, useState, useCallback } from "react";
import { Header } from "../components/Header";
import { AuthModal } from "../pages/auth-page/AuthModal"; // ✅ 새 위치로 변경

export default function RootLayout() {
    const navigate = useNavigate();

    const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
    const [authMode, setAuthMode] = useState("signin"); // ✅ "signin" | "signup"
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [userNickname, setUserNickname] = useState("");

    useEffect(() => {
        const savedNickname = localStorage.getItem("userNickname");
        const savedLoginState = localStorage.getItem("isLoggedIn");
        if (savedNickname) setUserNickname(savedNickname);
        if (savedLoginState === "true") setIsLoggedIn(true);
    }, []);

    // Header에서 예전 값("login")이 들어와도 안전하게 처리
    const normalizeMode = (mode) => {
        if (mode === "login") return "signin";
        if (mode === "signin") return "signin";
        if (mode === "signup") return "signup";
        return "signin";
    };

    const openAuthModal = useCallback((mode = "signin") => {
        setAuthMode(normalizeMode(mode));
        setIsAuthModalOpen(true);
    }, []);

    const closeAuthModal = useCallback(() => {
        setIsAuthModalOpen(false);
    }, []);

    const handleAuthSuccess = useCallback((nickname) => {
        setIsLoggedIn(true);
        localStorage.setItem("isLoggedIn", "true");

        if (nickname) {
            setUserNickname(nickname);
            localStorage.setItem("userNickname", nickname);
        }

        // 혹시 모달 내부에서 onClose를 안 부르는 케이스 대비
        setIsAuthModalOpen(false);
    }, []);

    // Header가 쓰던 pageKey를 라우팅으로 매핑
    const handleNavigate = useCallback(
        (pageKey) => {
            if (pageKey === "home") navigate("/");
            if (pageKey === "board") navigate("/boards/1/recipe");
            if (pageKey === "community") navigate("/boards/2/free");
            if (pageKey === "profile") navigate("/me"); // 추후 만들면 연결
        },
        [navigate]
    );

    return (
        <div className="min-h-screen bg-[#f5f1eb]">
            <Header
                onOpenAuth={openAuthModal}
                onNavigate={handleNavigate}
                isLoggedIn={isLoggedIn}
                userNickname={userNickname}
                // 필요하면 나중에 더 연결
                onRandomRecipe={() => {}}
                onNotificationClick={() => {}}
            />

            <Outlet />

            <AuthModal
                isOpen={isAuthModalOpen}
                onClose={closeAuthModal}
                mode={authMode} // ✅ "signin" | "signup"
                onAuthSuccess={handleAuthSuccess}
                onModeChange={(mode) => setAuthMode(normalizeMode(mode))}
            />
        </div>
    );
}
