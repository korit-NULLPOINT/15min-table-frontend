export const targetData = {
    1: 'RECIPE',
    2: 'FREE',
    3: 'QNA',
    4: 'NOTICE',
};
